@echo off
color 0A

:menu
cls
echo ================================================
echo          Welcome to the BAT service!
echo          ZeroScript Ultra - Service
echo ================================================
echo.
echo   [0]  Timer       - change delay (1.5 - 12 sec)
echo   [1]  Diagnostic  - check system status
echo   [2]  Statistics  - show stats and session counter
echo   [9]  Exit
echo.
set /p choice="  Choose: "

if "%choice%"=="0" goto timer
if "%choice%"=="1" goto diag
if "%choice%"=="2" goto stats
if "%choice%"=="9" exit
goto menu

:diag
cls
color 0A
echo ================================================
echo              DIAGNOSTIC
echo ================================================
echo.
echo   Checking system status...
echo.

echo   -- CONFIG --
if exist "user.config.json" (
  color 0A
  echo   [OK]   Config loaded
) else (
  color 0C
  echo   [FAIL] Config NOT loaded
  color 0A
)

echo.

echo   -- EXTENSION --
if exist "extension\manifest.json" (
  color 0A
  echo   [OK]   Extension found
) else (
  color 0C
  echo   [FAIL] Extension NOT found
  color 0A
)

if exist "extension\core\main.js" (
  color 0A
  echo   [OK]   Core files found
) else (
  color 0C
  echo   [FAIL] Core files NOT found
  color 0A
)

if exist "extension\providers\" (
  color 0A
  echo   [OK]   Providers found
) else (
  color 0C
  echo   [FAIL] Providers NOT found
  color 0A
)

if exist "extension\background\" (
  color 0A
  echo   [OK]   Background found
) else (
  color 0C
  echo   [FAIL] Background NOT found
  color 0A
)

echo.

echo   -- BRIDGE --
tasklist /FI "IMAGENAME eq python.exe" 2>nul | find /I "python.exe" >nul 2>&1
if "%errorlevel%"=="0" (
  color 0A
  echo   [OK]   Bridge connected
) else (
  color 0C
  echo   [FAIL] Bridge NOT connected
  color 0A
)

echo.

echo   -- ROBLOX STUDIO --
tasklist /FI "IMAGENAME eq RobloxStudioBeta.exe" 2>nul | find /I "RobloxStudioBeta.exe" >nul 2>&1
if "%errorlevel%"=="0" (
  color 0A
  echo   [OK]   Roblox Studio running
) else (
  color 0C
  echo   [FAIL] Roblox Studio NOT running
  color 0A
)

echo.

echo   -- NETWORK --
netstat -an 2>nul | find ":8080" >nul 2>&1
if "%errorlevel%"=="0" (
  color 0A
  echo   [OK]   Port 8080 open
) else (
  color 0C
  echo   [FAIL] Port 8080 closed
  color 0A
)

echo.

echo   -- SYSTEM --
color 0A
echo   Service: ZeroScript Ultra
ver

echo.
echo ================================================
pause
goto menu

:timer
cls
color 0A
echo ================================================
echo                    TIMER
echo ================================================
echo.
echo   Enter delay in MILLISECONDS.
echo.
echo   Fast:      1500  (1.5 sec)
echo   Normal:    4000  (4 sec)
echo   RECOMMEND: 6000  (6 sec)
echo   Careful:   8000  (8 sec)
echo   Max:       12000 (12 sec)
echo.
echo   Type B to go back to menu.
echo.
set /p ms="  Milliseconds (1500 - 12000): "

if /i "%ms%"=="b" goto menu
if "%ms%"=="" goto timer

if %ms% LSS 1500 (
  echo   Too small! Minimum 1500 ms. Press any key...
  pause >nul
  goto timer
)
if %ms% GTR 12000 (
  echo   Too big! Maximum 12000 ms. Press any key...
  pause >nul
  goto timer
)

cls
color 0A
echo   Applying: %ms% ms...
echo.

(
  echo {
  echo   "delayMin": %ms%,
  echo   "delayMax": %ms%,
  echo   "errorDelayMin": 5000,
  echo   "errorDelayMax": 15000,
  echo   "errorBackoff": 1.8,
  echo   "errorMaxWait": 60000,
  echo   "logMaxEntries": 500,
  echo   "enabled": true
  echo }
) > "user.config.json"

echo   Done!
echo.
echo   IMPORTANT: to apply the changes:
echo     1. Open chrome://extensions
echo     2. Find ZeroScriptUltra
echo     3. Click Reload
echo     4. Refresh the AI tab (F5)
echo.
pause
goto menu

:stats
cls
color 0A
echo ================================================
echo              STATISTICS
echo ================================================
echo.

echo   -- SESSION LOGS --
if exist "logs\" (
  dir /b /o-d "logs\" 2>nul | findstr /r "." >nul
  if "%errorlevel%"=="0" (echo   [OK]   Logs folder exists
    echo.
    echo   Recent files:
    dir /b /o-d "logs\" 2>nul
  ) else (
    color 0C
    echo   [FAIL] Logs folder is empty
    color 0A
  )
) else (
  color 0C
  echo   [FAIL] Logs folder not found
  color 0A
)

echo.
echo   -- SYSTEM INFO --
color 0A
echo   User: %USERNAME%
echo   Computer: %COMPUTERNAME%
echo   Date: %DATE%
echo   Time: %TIME%

echo.
echo   -- SESSION COUNTER --
set /a count=0
if exist "logs\bridge_debug.log" (
  for /f %%A in ('findstr /r /c:"start" "logs\bridge_debug.log" 2^>nul ^| find /c /v ""') do set count=%%A
)
echo   Sessions started: %count%

echo.
echo ================================================
pause
goto menu