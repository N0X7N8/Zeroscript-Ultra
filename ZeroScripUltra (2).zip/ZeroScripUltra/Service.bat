@echo off
chcp 65001 >nul
title ZeroScript Ultra - Service
color 0A

:menu
cls
echo ================================================
echo          Welcome to the BAT service!
echo          ZeroScript Ultra - Timer Settings
echo ================================================
echo.

rem ── Читаем текущий delayMin из user.config.json ──
set "CURRENT_DELAY=not set"
if exist "user.config.json" (
  for /f "tokens=2 delims=:," %%a in ('findstr "delayMin" "user.config.json"') do (
    set "CURRENT_DELAY=%%a"
  )
  set "CURRENT_DELAY=%CURRENT_DELAY: =%"
)

echo   Current delay: %CURRENT_DELAY% ms
echo.
echo   [0]  Timer  - change delay (1.5 - 12 sec)
echo   [9]  Exit
echo.
set /p choice="  Choose: "

if "%choice%"=="0" goto timer
if "%choice%"=="9" exit

echo   Invalid choice. Press any key...
pause >nul
goto menu

:timer
cls
echo ================================================
echo                    TIMER
echo ================================================
echo.
echo   Enter delay in MILLISECONDS.
echo.
echo   Fast:      1500  (1.5 sec)
echo   Normal:    4000  (4 sec)
echo   RECOMMEND: 6000  (6 sec)
echo   Careful:   8000  (8 sec)
echo   Max:       12000 (12 sec)
echo.
echo   Type B to go back to menu.
echo.
set /p ms="  Milliseconds (1500 - 12000): "

if /i "%ms%"=="b" goto menu
if "%ms%"=="" goto timer

if %ms% LSS 1500 (
  echo   Too small! Minimum 1500 ms. Press any key...
  pause >nul
  goto timer
)
if %ms% GTR 12000 (
  echo   Too big! Maximum 12000 ms. Press any key...
  pause >nul
  goto timer
)

cls
echo   Applying: %ms% ms...
echo.

(
  echo {
  echo   "delayMin": %ms%,
  echo   "delayMax": %ms%,
  echo   "errorDelayMin": 5000,
  echo   "errorDelayMax": 15000,
  echo   "errorBackoff": 1.8,
  echo   "errorMaxWait": 60000,
  echo   "logMaxEntries": 500,
  echo   "enabled": true
  echo }
) > "user.config.json"

echo   Done!
echo.
echo   IMPORTANT: to apply the changes:
echo     1. Open chrome://extensions
echo     2. Find ZeroScriptUltra
echo     3. Click Reload
echo     4. Refresh the AI tab (F5)
echo.
pause
goto menu