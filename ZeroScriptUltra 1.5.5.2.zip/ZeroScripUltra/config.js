{
  "delayMin": 1500,
  "delayMax": 12000,
  "errorDelayMin": 5000,
  "errorDelayMax": 15000,
  "errorBackoff": 1.8,
  "errorMaxWait": 60000,
  "logMaxEntries": 500,
  "enabled": true
}